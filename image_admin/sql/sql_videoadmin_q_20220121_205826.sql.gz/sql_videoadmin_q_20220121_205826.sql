-- MySQL dump 10.13  Distrib 5.7.34, for Linux (x86_64)
--
-- Host: localhost    Database: sql_videoadmin_q
-- ------------------------------------------------------
-- Server version	5.7.34-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ywsm_common_admin`
--

DROP TABLE IF EXISTS `ywsm_common_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ywsm_common_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '后台管理员表',
  `username` varchar(255) NOT NULL COMMENT '用户名',
  `password` varchar(255) NOT NULL COMMENT '密码',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态 1正常 2禁用',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `role_id` int(11) NOT NULL COMMENT '角色ID',
  `city_config_id` int(11) NOT NULL DEFAULT '0' COMMENT '省市ID',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `mobile` varchar(255) NOT NULL COMMENT '手机号',
  `token` varchar(255) DEFAULT NULL COMMENT 'token',
  `token_flush_at` datetime DEFAULT NULL COMMENT 'token刷新时间',
  `is_no_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否可删除[0 可以 1不可以]',
  `city_config_arr` varchar(255) NOT NULL COMMENT '城市JSON数据',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ywsm_common_admin`
--

LOCK TABLES `ywsm_common_admin` WRITE;
/*!40000 ALTER TABLE `ywsm_common_admin` DISABLE KEYS */;
INSERT INTO `ywsm_common_admin` VALUES (1,'admin_example','1712bd12a72ffd99ee82b1110385b69e',1,'2021-05-21 19:33:18',1,282,'','13540295237','ee1787e97e4d1b609f8b8058825a354f','2022-01-21 20:17:57',1,'[\"22\",\"282\"]'),(3,'admin_example1','7038e563052562832ea7cb7c443c6ea1',1,'2021-05-22 12:38:37',1,282,'','13540295237','12fc06576e9d0d4b79099e402ceb9eb5','2022-01-21 20:55:52',0,'[\"22\",\"282\"]');
/*!40000 ALTER TABLE `ywsm_common_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ywsm_common_auth`
--

DROP TABLE IF EXISTS `ywsm_common_auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ywsm_common_auth` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '操作权限',
  `role_id` int(11) NOT NULL COMMENT '角色ID',
  `is_no_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否可删除[0 可以 1不可以]',
  `route_ids` text COMMENT '可操作路由(为空表示所有)',
  `create_time` datetime DEFAULT NULL,
  `menu_ids` text COMMENT '可操作菜单(为空表示所有)',
  `menu_select_ids` text COMMENT '可操作菜单(仅用于权限加载)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ywsm_common_auth`
--

LOCK TABLES `ywsm_common_auth` WRITE;
/*!40000 ALTER TABLE `ywsm_common_auth` DISABLE KEYS */;
INSERT INTO `ywsm_common_auth` VALUES (1,1,1,'','2021-05-21 16:47:21','',NULL),(2,2,0,NULL,'2021-05-22 11:03:49','2,3,4','2,3,4,1');
/*!40000 ALTER TABLE `ywsm_common_auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ywsm_common_city_config`
--

DROP TABLE IF EXISTS `ywsm_common_city_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ywsm_common_city_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '省市管理',
  `name` varchar(255) NOT NULL COMMENT '省市名称',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT '父级ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=426 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ywsm_common_city_config`
--

LOCK TABLES `ywsm_common_city_config` WRITE;
/*!40000 ALTER TABLE `ywsm_common_city_config` DISABLE KEYS */;
INSERT INTO `ywsm_common_city_config` VALUES (1,'北京市',0),(2,'天津市',0),(3,'上海市',0),(4,'重庆市',0),(5,'河北省',0),(6,'山西省',0),(7,'台湾省',0),(8,'辽宁省',0),(9,'吉林省',0),(10,'黑龙江省',0),(11,'江苏省',0),(12,'浙江省',0),(13,'安徽省',0),(14,'福建省',0),(15,'江西省',0),(16,'山东省',0),(17,'河南省',0),(18,'湖北省',0),(19,'湖南省',0),(20,'广东省',0),(21,'甘肃省',0),(22,'四川省',0),(23,'贵州省',0),(24,'海南省',0),(25,'云南省',0),(26,'青海省',0),(27,'陕西省',0),(28,'广西壮族自治区',0),(29,'西藏自治区',0),(30,'宁夏回族自治区',0),(31,'新疆维吾尔自治区',0),(32,'内蒙古自治区',0),(33,'澳门特别行政区',0),(34,'香港特别行政区',0),(35,'北京市',1),(36,'天津市',2),(37,'上海市',3),(38,'重庆市',4),(39,'石家庄市',5),(40,'唐山市',5),(41,'秦皇岛市',5),(42,'邯郸市',5),(43,'邢台市',5),(44,'保定市',5),(45,'张家口市',5),(46,'承德市',5),(47,'沧州市',5),(48,'廊坊市',5),(49,'衡水市',5),(50,'太原市',6),(51,'大同市',6),(52,'阳泉市',6),(53,'长治市',6),(54,'晋城市',6),(55,'朔州市',6),(56,'晋中市',6),(57,'运城市',6),(58,'忻州市',6),(59,'临汾市',6),(60,'吕梁市',6),(61,'台北市',7),(62,'高雄市',7),(63,'基隆市',7),(64,'台中市',7),(65,'台南市',7),(66,'新竹市',7),(67,'嘉义市',7),(68,'台北县',7),(69,'宜兰县',7),(70,'桃园县',7),(71,'新竹县',7),(72,'苗栗县',7),(73,'台中县',7),(74,'彰化县',7),(75,'南投县',7),(76,'云林县',7),(77,'嘉义县',7),(78,'台南县',7),(79,'高雄县',7),(80,'屏东县',7),(81,'澎湖县',7),(82,'台东县',7),(83,'花莲县',7),(84,'沈阳市',8),(85,'大连市',8),(86,'鞍山市',8),(87,'抚顺市',8),(88,'本溪市',8),(89,'丹东市',8),(90,'锦州市',8),(91,'营口市',8),(92,'阜新市',8),(93,'辽阳市',8),(94,'盘锦市',8),(95,'铁岭市',8),(96,'朝阳市',8),(97,'葫芦岛市',8),(98,'长春市',9),(99,'吉林市',9),(100,'四平市',9),(101,'辽源市',9),(102,'通化市',9),(103,'白山市',9),(104,'松原市',9),(105,'白城市',9),(106,'延边朝鲜族自治州',9),(107,'哈尔滨市',10),(108,'齐齐哈尔市',10),(109,'鹤岗市',10),(110,'双鸭山市',10),(111,'鸡西市',10),(112,'大庆市',10),(113,'伊春市',10),(114,'牡丹江市',10),(115,'佳木斯市',10),(116,'七台河市',10),(117,'黑河市',10),(118,'绥化市',10),(119,'大兴安岭地区',10),(120,'南京市',11),(121,'无锡市',11),(122,'徐州市',11),(123,'常州市',11),(124,'苏州市',11),(125,'南通市',11),(126,'连云港市',11),(127,'淮安市',11),(128,'盐城市',11),(129,'扬州市',11),(130,'镇江市',11),(131,'泰州市',11),(132,'宿迁市',11),(133,'杭州市',12),(134,'宁波市',12),(135,'温州市',12),(136,'嘉兴市',12),(137,'湖州市',12),(138,'绍兴市',12),(139,'金华市',12),(140,'衢州市',12),(141,'舟山市',12),(142,'台州市',12),(143,'丽水市',12),(144,'合肥市',13),(145,'芜湖市',13),(146,'蚌埠市',13),(147,'淮南市',13),(148,'马鞍山市',13),(149,'淮北市',13),(150,'铜陵市',13),(151,'安庆市',13),(152,'黄山市',13),(153,'滁州市',13),(154,'阜阳市',13),(155,'宿州市',13),(156,'巢湖市',13),(157,'六安市',13),(158,'亳州市',13),(159,'池州市',13),(160,'宣城市',13),(161,'福州市',14),(162,'厦门市',14),(163,'莆田市',14),(164,'三明市',14),(165,'泉州市',14),(166,'漳州市',14),(167,'南平市',14),(168,'龙岩市',14),(169,'宁德市',14),(170,'南昌市',15),(171,'景德镇市',15),(172,'萍乡市',15),(173,'九江市',15),(174,'新余市',15),(175,'鹰潭市',15),(176,'赣州市',15),(177,'吉安市',15),(178,'宜春市',15),(179,'抚州市',15),(180,'上饶市',15),(181,'济南市',16),(182,'青岛市',16),(183,'淄博市',16),(184,'枣庄市',16),(185,'东营市',16),(186,'烟台市',16),(187,'潍坊市',16),(188,'济宁市',16),(189,'泰安市',16),(190,'威海市',16),(191,'日照市',16),(192,'莱芜市',16),(193,'临沂市',16),(194,'德州市',16),(195,'聊城市',16),(196,'滨州市',16),(197,'菏泽市',16),(198,'郑州市',17),(199,'开封市',17),(200,'洛阳市',17),(201,'平顶山市',17),(202,'安阳市',17),(203,'鹤壁市',17),(204,'新乡市',17),(205,'焦作市',17),(206,'濮阳市',17),(207,'许昌市',17),(208,'漯河市',17),(209,'三门峡市',17),(210,'南阳市',17),(211,'商丘市',17),(212,'信阳市',17),(213,'周口市',17),(214,'驻马店市',17),(215,'济源市',17),(216,'武汉市',18),(217,'黄石市',18),(218,'十堰市',18),(219,'荆州市',18),(220,'宜昌市',18),(221,'襄樊市',18),(222,'鄂州市',18),(223,'荆门市',18),(224,'孝感市',18),(225,'黄冈市',18),(226,'咸宁市',18),(227,'随州市',18),(228,'仙桃市',18),(229,'天门市',18),(230,'潜江市',18),(231,'神农架林区',18),(232,'恩施土家族苗族自治州',18),(233,'长沙市',19),(234,'株洲市',19),(235,'湘潭市',19),(236,'衡阳市',19),(237,'邵阳市',19),(238,'岳阳市',19),(239,'常德市',19),(240,'张家界市',19),(241,'益阳市',19),(242,'郴州市',19),(243,'永州市',19),(244,'怀化市',19),(245,'娄底市',19),(246,'湘西土家族苗族自治州',19),(247,'广州市',20),(248,'深圳市',20),(249,'珠海市',20),(250,'汕头市',20),(251,'韶关市',20),(252,'佛山市',20),(253,'江门市',20),(254,'湛江市',20),(255,'茂名市',20),(256,'肇庆市',20),(257,'惠州市',20),(258,'梅州市',20),(259,'汕尾市',20),(260,'河源市',20),(261,'阳江市',20),(262,'清远市',20),(263,'东莞市',20),(264,'中山市',20),(265,'潮州市',20),(266,'揭阳市',20),(267,'云浮市',20),(268,'兰州市',21),(269,'金昌市',21),(270,'白银市',21),(271,'天水市',21),(272,'嘉峪关市',21),(273,'武威市',21),(274,'张掖市',21),(275,'平凉市',21),(276,'酒泉市',21),(277,'庆阳市',21),(278,'定西市',21),(279,'陇南市',21),(280,'临夏回族自治州',21),(281,'甘南藏族自治州',21),(282,'成都市',22),(283,'自贡市',22),(284,'攀枝花市',22),(285,'泸州市',22),(286,'德阳市',22),(287,'绵阳市',22),(288,'广元市',22),(289,'遂宁市',22),(290,'内江市',22),(291,'乐山市',22),(292,'南充市',22),(293,'眉山市',22),(294,'宜宾市',22),(295,'广安市',22),(296,'达州市',22),(297,'雅安市',22),(298,'巴中市',22),(299,'资阳市',22),(300,'阿坝藏族羌族自治州',22),(301,'甘孜藏族自治州',22),(302,'凉山彝族自治州',22),(303,'贵阳市',23),(304,'六盘水市',23),(305,'遵义市',23),(306,'安顺市',23),(307,'铜仁地区',23),(308,'毕节地区',23),(309,'黔西南布依族苗族自治州',23),(310,'黔东南苗族侗族自治州',23),(311,'黔南布依族苗族自治州',23),(312,'海口市',24),(313,'三亚市',24),(314,'五指山市',24),(315,'琼海市',24),(316,'儋州市',24),(317,'文昌市',24),(318,'万宁市',24),(319,'东方市',24),(320,'澄迈县',24),(321,'定安县',24),(322,'屯昌县',24),(323,'临高县',24),(324,'白沙黎族自治县',24),(325,'昌江黎族自治县',24),(326,'乐东黎族自治县',24),(327,'陵水黎族自治县',24),(328,'保亭黎族苗族自治县',24),(329,'琼中黎族苗族自治县',24),(330,'昆明市',25),(331,'曲靖市',25),(332,'玉溪市',25),(333,'保山市',25),(334,'昭通市',25),(335,'丽江市',25),(336,'思茅市',25),(337,'临沧市',25),(338,'文山壮族苗族自治州',25),(339,'红河哈尼族彝族自治州',25),(340,'西双版纳傣族自治州',25),(341,'楚雄彝族自治州',25),(342,'大理白族自治州',25),(343,'德宏傣族景颇族自治州',25),(344,'怒江傈傈族自治州',25),(345,'迪庆藏族自治州',25),(346,'西宁市',26),(347,'海东地区',26),(348,'海北藏族自治州',26),(349,'黄南藏族自治州',26),(350,'海南藏族自治州',26),(351,'果洛藏族自治州',26),(352,'玉树藏族自治州',26),(353,'海西蒙古族藏族自治州',26),(354,'西安市',27),(355,'铜川市',27),(356,'宝鸡市',27),(357,'咸阳市',27),(358,'渭南市',27),(359,'延安市',27),(360,'汉中市',27),(361,'榆林市',27),(362,'安康市',27),(363,'商洛市',27),(364,'南宁市',28),(365,'柳州市',28),(366,'桂林市',28),(367,'梧州市',28),(368,'北海市',28),(369,'防城港市',28),(370,'钦州市',28),(371,'贵港市',28),(372,'玉林市',28),(373,'百色市',28),(374,'贺州市',28),(375,'河池市',28),(376,'来宾市',28),(377,'崇左市',28),(378,'拉萨市',29),(379,'那曲地区',29),(380,'昌都地区',29),(381,'山南地区',29),(382,'日喀则地区',29),(383,'阿里地区',29),(384,'林芝地区',29),(385,'银川市',30),(386,'石嘴山市',30),(387,'吴忠市',30),(388,'固原市',30),(389,'中卫市',30),(390,'乌鲁木齐市',31),(391,'克拉玛依市',31),(392,'石河子市',31),(393,'阿拉尔市',31),(394,'图木舒克市',31),(395,'五家渠市',31),(396,'吐鲁番市',31),(397,'阿克苏市',31),(398,'喀什市',31),(399,'哈密市',31),(400,'和田市',31),(401,'阿图什市',31),(402,'库尔勒市',31),(403,'昌吉市',31),(404,'阜康市',31),(405,'米泉市',31),(406,'博乐市',31),(407,'伊宁市',31),(408,'奎屯市',31),(409,'塔城市',31),(410,'乌苏市',31),(411,'阿勒泰市',31),(412,'呼和浩特市',32),(413,'包头市',32),(414,'乌海市',32),(415,'赤峰市',32),(416,'通辽市',32),(417,'鄂尔多斯市',32),(418,'呼伦贝尔市',32),(419,'巴彦淖尔市',32),(420,'乌兰察布市',32),(421,'锡林郭勒盟',32),(422,'兴安盟',32),(423,'阿拉善盟',32),(424,'澳门特别行政区',33),(425,'香港特别行政区',34);
/*!40000 ALTER TABLE `ywsm_common_city_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ywsm_common_log`
--

DROP TABLE IF EXISTS `ywsm_common_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ywsm_common_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '后台操作日志',
  `admin_id` int(11) NOT NULL DEFAULT '0' COMMENT '操作者',
  `create_time` datetime DEFAULT NULL COMMENT '操作时间',
  `ip` varchar(255) NOT NULL DEFAULT '' COMMENT '操作IP',
  `action` varchar(255) NOT NULL DEFAULT '' COMMENT '操作action',
  `content` longtext COMMENT '操作内容',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '操作类型[1新增2修改3删除4登录]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ywsm_common_log`
--

LOCK TABLES `ywsm_common_log` WRITE;
/*!40000 ALTER TABLE `ywsm_common_log` DISABLE KEYS */;
INSERT INTO `ywsm_common_log` VALUES (1,1,'2021-05-24 10:28:28','127.0.0.1','/product-more/edit','{\"before\":{\"id\":3,\"detail\":\"<p>\\u6492\\u65e6\\u6492\\u65e6<\\/p>\",\"create_time\":\"2021-05-22 22:08:41\",\"view_num\":0,\"status\":1,\"order_num\":13,\"is_delete\":0,\"product_type_id\":2,\"name\":\"\\u6d4b\\u8bd51\",\"delete_time\":null,\"image\":\"\\/uploads\\/file\\/bBhsQ8qQfSgL1DNp.jpg\",\"broad_list\":\"\\/uploads\\/file\\/rcOR6TJtqFTnPeDr.jpg\",\"product_type_arr\":\"[\\\"1\\\",\\\"2\\\"]\",\"sku_info\":\"{\\\"properties\\\":[\\\"\\\\u7ea2\\\\u8272\\\",\\\"\\\\u84dd\\\\u8272\\\"],\\\"sku\\\":[{\\\"name\\\":\\\"\\\\u7ea2\\\\u8272\\\",\\\"stock\\\":\\\"10\\\",\\\"price\\\":\\\"110\\\",\\\"consume_stock\\\":\\\"0\\\",\\\"sku_image\\\":\\\"\\\"},{\\\"name\\\":\\\"\\\\u84dd\\\\u8272\\\",\\\"stock\\\":\\\"10\\\",\\\"price\\\":\\\"123\\\",\\\"consume_stock\\\":\\\"0\\\",\\\"sku_image\\\":\\\"\\\"}]}\",\"type\":1},\"last\":{\"image\":\"\\/uploads\\/file\\/bBhsQ8qQfSgL1DNp.jpg\",\"order_num\":\"13\",\"status\":1,\"detail\":\"<p>\\u6492\\u65e6\\u6492\\u65e6<\\/p>\",\"product_type_id\":\"2\",\"name\":\"\\u6d4b\\u8bd5\\u4f46\\u89c4\\u683c1\",\"broad_list\":\"\\/uploads\\/file\\/rcOR6TJtqFTnPeDr.jpg\",\"product_type_arr\":\"[\\\"1\\\",\\\"2\\\"]\",\"sku_info\":\"{\\\"properties\\\":[\\\"\\\\u7ea2\\\\u8272\\\",\\\"\\\\u84dd\\\\u8272\\\"],\\\"sku\\\":[{\\\"name\\\":\\\"\\\\u7ea2\\\\u8272\\\",\\\"stock\\\":\\\"10\\\",\\\"price\\\":\\\"110\\\",\\\"consume_stock\\\":\\\"0\\\",\\\"sku_image\\\":\\\"\\\"},{\\\"name\\\":\\\"\\\\u84dd\\\\u8272\\\",\\\"stock\\\":\\\"10\\\",\\\"price\\\":\\\"123\\\",\\\"consume_stock\\\":\\\"0\\\",\\\"sku_image\\\":\\\"\\\"}]}\",\"type\":1}}',2),(2,1,'2021-05-24 10:31:46','127.0.0.1','/other-config/edit','{\"before\":{\"id\":1,\"service_phone\":\"135402952378\",\"present_percent\":0},\"last\":{\"service_phone\":\"13540295237\",\"present_percent\":0}}',2),(3,1,'2021-05-24 15:10:53','127.0.0.1','/menu/edit','{\"before\":\"\",\"last\":{\"title\":\"\\u5e73\\u53f0\\u7ba1\\u7406\",\"path\":\"\",\"status\":1,\"parent_id\":0,\"order_num\":true,\"create_time\":\"2021-05-24 15:10:53\"}}',1),(4,1,'2021-05-24 15:11:30','127.0.0.1','/menu/edit','{\"before\":\"\",\"last\":{\"title\":\"\\u5361\\u5238\\u7ba1\\u7406\",\"path\":\"\\/platform\\/coupon\",\"status\":1,\"parent_id\":\"20\",\"order_num\":0,\"create_time\":\"2021-05-24 15:11:30\"}}',1),(5,1,'2021-05-24 16:03:28','127.0.0.1','/coupon/edit','{\"before\":\"\",\"last\":{\"name\":\"\\u65b0\\u4eba\\u5238\",\"type\":\"1\",\"provide_type\":\"2\",\"number\":0,\"recevie_num\":1,\"time_type\":\"2\",\"price\":\"10\",\"full_price\":\"100\",\"receive_time_num\":\"60\",\"create_time\":\"2021-05-24 16:03:28\"}}',1),(6,1,'2021-05-24 17:06:03','127.0.0.1','/menu/edit','{\"before\":\"\",\"last\":{\"title\":\"\\u5361\\u5238\\u9886\\u53d6\\u8bb0\\u5f55\",\"path\":\"\\/platform\\/coupon-receive-record\",\"status\":1,\"parent_id\":\"20\",\"order_num\":0,\"create_time\":\"2021-05-24 17:06:03\"}}',1),(7,1,'2021-05-25 15:34:45','127.0.0.1','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"ba803699a471db339c0a4883d69dc602\",\"token_flush_at\":\"2021-05-24 09:08:53\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(8,1,'2021-05-25 15:38:50','127.0.0.1','/product/edit','{\"before\":\"\",\"last\":{\"image\":\"\\/uploads\\/file\\/tpieXwAHTE8GTz9i.jpg\",\"order_num\":\"9\",\"status\":1,\"detail\":\"<p>\\u5b9e\\u6253\\u5b9e<\\/p>\",\"product_type_id\":\"2\",\"name\":\"\\u6d4b\\u8bd51\",\"stock\":\"100\",\"price\":\"20\",\"broad_list\":\"\\/uploads\\/file\\/pQRPRBrgHcO85Okg.jpg\",\"product_type_arr\":\"[\\\"1\\\",\\\"2\\\"]\",\"create_time\":\"2021-05-25 15:38:50\"}}',1),(9,1,'2021-05-26 11:33:35','127.0.0.1','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"4c0ddfd2580275f05ef18d0cdad18058\",\"token_flush_at\":\"2021-05-25 15:34:45\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(10,1,'2021-05-26 11:36:58','127.0.0.1','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"f4fcfffe91e510ab0cb065e7321b99f5\",\"token_flush_at\":\"2021-05-26 11:33:35\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(11,1,'2021-05-26 18:35:00','172.19.111.206','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"83006a87bded0b209c6d76096f55cf90\",\"token_flush_at\":\"2021-05-26 11:36:58\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(12,1,'2021-05-27 10:21:42','172.19.111.206','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"66e2a41b5e2e4428bc93d4e3d0451f08\",\"token_flush_at\":\"2021-05-26 18:35:00\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(13,1,'2021-07-09 08:58:22','127.0.0.1','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"1ad04f592dc68453395887a6a87679cf\",\"token_flush_at\":\"2021-05-27 10:21:42\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(14,1,'2021-07-12 11:55:25','127.0.0.1','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"5a951fc1045fbcfa7ed0a2c85094605c\",\"token_flush_at\":\"2021-07-09 08:58:22\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(15,1,'2022-01-17 11:10:54','127.0.0.1','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"5f7374ae4e074c2b59a84aaa4cedf81e\",\"token_flush_at\":\"2021-07-12 11:55:25\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(16,1,'2022-01-17 15:10:26','127.0.0.1','/menu/edit','{\"before\":\"\",\"last\":{\"title\":\"\\u89c6\\u9891\\u5206\\u7c7b\",\"path\":\"\\/system\\/video-type\",\"status\":1,\"parent_id\":\"7\",\"order_num\":0,\"create_time\":\"2022-01-17 15:10:26\"}}',1),(17,1,'2022-01-17 15:12:23','127.0.0.1','/yw-video-type/edit','{\"before\":\"\",\"last\":{\"status\":1,\"order_num\":\"100\",\"name\":\"\\u7cbe\\u54c1\\u63a8\\u8350\",\"update_time\":\"2022-01-17 15:12:23\",\"remark\":\"\",\"create_time\":\"2022-01-17 15:12:23\"}}',1),(18,1,'2022-01-17 15:13:08','127.0.0.1','/yw-video-type/edit','{\"before\":\"\",\"last\":{\"status\":1,\"order_num\":\"100\",\"name\":\"\\u7cbe\\u54c1\\u63a8\\u8350\",\"update_time\":\"2022-01-17 15:13:08\",\"remark\":\"\\u7cbe\\u54c1\\u63a8\\u8350\"}}',2),(19,1,'2022-01-17 15:31:16','127.0.0.1','/yw-city/edit','{\"before\":\"\",\"last\":{\"status\":1,\"order_num\":\"10\",\"name\":\"\\u6210\\u90fd\",\"update_time\":\"2022-01-17 15:31:16\",\"remark\":\"\\u6210\\u90fd\",\"create_time\":\"2022-01-17 15:31:16\"}}',1),(20,1,'2022-01-17 16:12:16','127.0.0.1','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"bc5c4648223b38c5a781c4231daa4cc0\",\"token_flush_at\":\"2022-01-17 11:10:54\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(21,1,'2022-01-17 16:27:57','127.0.0.1','/yw-beaufiful/edit','{\"before\":\"\",\"last\":{\"city_config_id\":\"1\",\"status\":1,\"image\":\"http:\\/\\/jiuzi.tp.test\\/uploads\\/file\\/ePRAk2bLwySzBcWa.jpg\",\"remark\":\"123\",\"order_num\":\"12\",\"name\":\"123\",\"update_time\":\"2022-01-17 16:27:57\",\"create_time\":\"2022-01-17 16:27:57\"}}',1),(22,1,'2022-01-19 09:39:49','127.0.0.1','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"93a8c4d84fdc6e94bf4d94de3668efa2\",\"token_flush_at\":\"2022-01-17 16:12:16\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(23,1,'2022-01-19 09:59:59','127.0.0.1','/yw-video/edit','{\"before\":\"\",\"last\":{\"video_type_id\":\"1\",\"status\":1,\"image\":\"http:\\/\\/jiuzi.tp.test\\/uploads\\/file\\/XBjqMFENO988V1Ki.png\",\"remark\":\"12\",\"order_num\":\"12\",\"name\":\"123\",\"update_time\":\"2022-01-19 09:59:59\",\"video_path\":\"\",\"video_url\":\"\\/uploads\\/file\\/qfcqwL8Qb0jWmJd2.mp4\",\"type\":\"1\",\"create_time\":\"2022-01-19 09:59:59\"}}',1),(24,1,'2022-01-19 14:57:28','127.0.0.1','/menu/edit','{\"before\":{\"id\":7,\"title\":\"\\u7cfb\\u7edf\\u914d\\u7f6e\",\"path\":\"\",\"status\":1,\"parent_id\":0,\"create_time\":\"2021-05-22 15:12:44\",\"order_num\":0,\"is_load\":1},\"last\":{\"title\":\"\\u89c6\\u9891\\u7ba1\\u7406\",\"path\":\"\",\"status\":1,\"parent_id\":0,\"order_num\":0}}',2),(25,1,'2022-01-19 14:57:39','127.0.0.1','/menu/edit','{\"before\":\"\",\"last\":{\"title\":\"\\u9009\\u7f8e\\u7ba1\\u7406\",\"path\":\"\",\"status\":1,\"parent_id\":0,\"order_num\":true,\"create_time\":\"2022-01-19 14:57:39\"}}',1),(26,1,'2022-01-19 14:57:46','127.0.0.1','/menu/edit','{\"before\":{\"id\":24,\"title\":\"\\u57ce\\u5e02\\u7ba1\\u7406\",\"path\":\"\\/system\\/city\",\"status\":1,\"parent_id\":7,\"create_time\":\"2022-01-17 15:10:26\",\"order_num\":0,\"is_load\":1},\"last\":{\"title\":\"\\u57ce\\u5e02\\u7ba1\\u7406\",\"path\":\"\\/system\\/city\",\"status\":1,\"parent_id\":\"27\",\"order_num\":0}}',2),(27,1,'2022-01-19 14:57:51','127.0.0.1','/menu/edit','{\"before\":{\"id\":25,\"title\":\"\\u9009\\u7f8e\\u5217\\u8868\",\"path\":\"\\/system\\/beautiful\",\"status\":1,\"parent_id\":7,\"create_time\":\"2022-01-17 15:10:26\",\"order_num\":0,\"is_load\":1},\"last\":{\"title\":\"\\u9009\\u7f8e\\u5217\\u8868\",\"path\":\"\\/system\\/beautiful\",\"status\":1,\"parent_id\":\"27\",\"order_num\":0}}',2),(28,1,'2022-01-19 15:07:31','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"9337e831ac9b42cf69e2777a275b80dd\",\"token_flush_at\":\"2022-01-19 09:39:49\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(29,1,'2022-01-19 15:08:00','185.135.73.218','/yw-beaufiful/edit','{\"before\":\"\",\"last\":{\"city_id\":\"1\",\"status\":1,\"image\":\"https:\\/\\/video.qlkc998.vip\\/uploads\\/file\\/cfZlGNlWDkTkPw2E.jpg\",\"remark\":\"123\",\"order_num\":\"12\",\"name\":\"123\",\"update_time\":\"2022-01-19 15:08:00\"}}',2),(30,1,'2022-01-19 15:19:31','185.135.73.218','/yw-video/edit','{\"before\":\"\",\"last\":{\"video_type_id\":\"1\",\"status\":1,\"image\":\"\\/uploads\\/file\\/UNvM2rB0SPMGZh9H.jpg\",\"remark\":\"12\",\"order_num\":\"12\",\"name\":\"123\",\"update_time\":\"2022-01-19 15:19:31\",\"video_path\":\"\",\"video_url\":\"\\/uploads\\/file\\/qfcqwL8Qb0jWmJd2.mp4\",\"type\":\"1\"}}',2),(31,1,'2022-01-19 15:21:37','185.135.73.218','/yw-video/edit','{\"before\":\"\",\"last\":{\"video_type_id\":\"1\",\"status\":1,\"image\":\"\\/uploads\\/file\\/Fk0wIMCso0CUNa2M.jpg\",\"remark\":\"12\",\"order_num\":\"12\",\"name\":\"123\",\"update_time\":\"2022-01-19 15:21:37\",\"video_path\":\"\",\"video_url\":\"\\/uploads\\/file\\/PODtVCn1BE8RWbUE.mp4\",\"type\":\"1\"}}',2),(32,1,'2022-01-19 15:21:56','185.135.73.218','/yw-beaufiful/edit','{\"before\":\"\",\"last\":{\"city_id\":\"1\",\"status\":1,\"image\":\"\\/uploads\\/file\\/p7CGjXO4KruY5n8B.jpg\",\"remark\":\"123\",\"order_num\":\"12\",\"name\":\"123\",\"update_time\":\"2022-01-19 15:21:56\"}}',2),(33,1,'2022-01-19 16:42:38','185.135.73.218','/admin/edit','{\"before\":{\"id\":3,\"username\":\"admin_example1\",\"password\":\"7038e563052562832ea7cb7c443c6ea1\",\"status\":1,\"create_time\":\"2021-05-22 12:38:37\",\"role_id\":2,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"8373b5c61a3fa0069529016b8366b6cc\",\"token_flush_at\":\"2021-05-22 12:38:44\",\"is_no_delete\":0,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":{\"username\":\"admin_example1\",\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\",\"status\":1,\"role_id\":\"1\",\"city_config_id\":\"282\",\"remark\":\"\",\"mobile\":\"13540295237\"}}',2),(34,3,'2022-01-19 16:42:56','185.135.73.218','/login/login','{\"before\":{\"id\":3,\"username\":\"admin_example1\",\"password\":\"7038e563052562832ea7cb7c443c6ea1\",\"status\":1,\"create_time\":\"2021-05-22 12:38:37\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"8373b5c61a3fa0069529016b8366b6cc\",\"token_flush_at\":\"2021-05-22 12:38:44\",\"is_no_delete\":0,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(35,1,'2022-01-19 16:43:47','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"b94e9b8e1472c8c01784cd59b75fb6cd\",\"token_flush_at\":\"2022-01-19 15:07:31\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(36,3,'2022-01-19 16:48:13','185.135.73.218','/yw-city/edit','{\"before\":\"\",\"last\":{\"status\":1,\"order_num\":\"12\",\"name\":\"\\u897f\\u5b89\",\"update_time\":\"2022-01-19 16:48:13\",\"remark\":\"\\u897f\\u5b89\",\"create_time\":\"2022-01-19 16:48:13\"}}',1),(37,3,'2022-01-19 17:03:39','185.135.73.218','/yw-video/edit','{\"before\":\"\",\"last\":{\"video_type_id\":\"1\",\"status\":1,\"image\":\"\\/uploads\\/file\\/JJaB7l7c4rF8KsY5.jpg\",\"remark\":\"123\",\"order_num\":\"123\",\"name\":\"234\",\"update_time\":\"2022-01-19 17:03:39\",\"video_path\":\"https:\\/\\/video.qlkc998.vip\\/\\/uploads\\/file\\/PODtVCn1BE8RWbUE.mp4\",\"video_url\":\"\",\"type\":\"2\",\"create_time\":\"2022-01-19 17:03:39\"}}',1),(38,1,'2022-01-19 17:32:52','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"17579482f9696329457cfd40b98b342f\",\"token_flush_at\":\"2022-01-19 16:43:47\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(39,1,'2022-01-19 17:41:55','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"a612c6fab418fd9b08a3472a2022a578\",\"token_flush_at\":\"2022-01-19 17:32:52\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(40,1,'2022-01-19 17:43:37','185.135.73.218','/yw-video-type/edit','{\"before\":\"\",\"last\":{\"status\":2,\"order_num\":\"\",\"name\":\"j\",\"update_time\":\"2022-01-19 17:43:37\",\"remark\":\"\",\"create_time\":\"2022-01-19 17:43:37\"}}',1),(41,1,'2022-01-19 17:59:53','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"05bac2c9e135624aaeeb3f477b5ada0c\",\"token_flush_at\":\"2022-01-19 17:41:55\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(42,3,'2022-01-20 13:49:00','185.135.73.218','/menu/edit','{\"before\":{\"id\":27,\"title\":\"\\u9009\\u7f8e\\u7ba1\\u7406\",\"path\":\"\",\"status\":1,\"parent_id\":0,\"create_time\":\"2022-01-19 14:57:39\",\"order_num\":1,\"is_load\":1},\"last\":{\"title\":\"\\u9009\\u7f8e\\u7ba1\\u7406\",\"path\":\"\",\"status\":2,\"parent_id\":0,\"order_num\":true}}',2),(43,3,'2022-01-20 13:49:06','185.135.73.218','/menu/edit','{\"before\":{\"id\":25,\"title\":\"\\u9009\\u7f8e\\u5217\\u8868\",\"path\":\"\\/system\\/beautiful\",\"status\":1,\"parent_id\":27,\"create_time\":\"2022-01-17 15:10:26\",\"order_num\":0,\"is_load\":1},\"last\":{\"title\":\"\\u9009\\u7f8e\\u5217\\u8868\",\"path\":\"\\/system\\/beautiful\",\"status\":2,\"parent_id\":\"27\",\"order_num\":0}}',2),(44,3,'2022-01-20 13:49:11','185.135.73.218','/menu/edit','{\"before\":{\"id\":24,\"title\":\"\\u57ce\\u5e02\\u7ba1\\u7406\",\"path\":\"\\/system\\/city\",\"status\":1,\"parent_id\":27,\"create_time\":\"2022-01-17 15:10:26\",\"order_num\":0,\"is_load\":1},\"last\":{\"title\":\"\\u57ce\\u5e02\\u7ba1\\u7406\",\"path\":\"\\/system\\/city\",\"status\":2,\"parent_id\":\"27\",\"order_num\":0}}',2),(45,3,'2022-01-20 19:17:29','185.135.73.218','/menu/edit','{\"before\":\"\",\"last\":{\"title\":\"\\u516c\\u544a\\u7ba1\\u7406\",\"path\":\"\",\"status\":1,\"parent_id\":0,\"order_num\":0,\"create_time\":\"2022-01-20 19:17:29\"}}',1),(46,3,'2022-01-20 19:17:44','185.135.73.218','/menu/edit','{\"before\":\"\",\"last\":{\"title\":\"\\u516c\\u544a\\u5217\\u8868\",\"path\":\"\\/system\\/notice\",\"status\":1,\"parent_id\":\"28\",\"order_num\":0,\"create_time\":\"2022-01-20 19:17:44\"}}',1),(47,3,'2022-01-20 19:18:07','185.135.73.218','/yw-notice/edit','{\"before\":\"\",\"last\":{\"title\":\"\\u6b22\\u8fce\\u52a0\\u5165\\u4e5d\\u7d2b\\u7231\\u604b\\uff0c\\u8d1f\\u8ddd\\u79bb\\u7684\\u63a5\\u89e6\\uff0c\\u5e1d\\u738b\\u822c\\u7684\\u9082\\u9005\\uff0c\\u5168\\u56fd\\u9876\\u7ea7\\u8d44\\u6e90\\uff0c\\u4e13\\u4e1a\\u7ea7\\u7684\\u670d\\u52a1\\uff01\\u6a21\\u7279 \\uff0c\\u7f51\\u7ea2\\uff0c\\u5fa1\\u59d0\\uff0c\\u841d\\u8389\\uff0c\\u7a7a\\u59d0\\uff0c\\u5b66\\u751f\\uff0c\\u5c11\\u5987\\uff0c\\u603b\\u6709\\u4e00\\u6b3e\\u5c5e\\u4e8e\\u4f60\\uff01\",\"detail\":\"<p><span style=\\\"color: rgb(51, 51, 51);\\\">\\u6b22\\u8fce\\u52a0\\u5165\\u4e5d\\u7d2b\\u7231\\u604b\\uff0c\\u8d1f\\u8ddd\\u79bb\\u7684\\u63a5\\u89e6\\uff0c\\u5e1d\\u738b\\u822c\\u7684\\u9082\\u9005\\uff0c\\u5168\\u56fd\\u9876\\u7ea7\\u8d44\\u6e90\\uff0c\\u4e13\\u4e1a\\u7ea7\\u7684\\u670d\\u52a1\\uff01\\u6a21\\u7279 \\uff0c\\u7f51\\u7ea2\\uff0c\\u5fa1\\u59d0\\uff0c\\u841d\\u8389\\uff0c\\u7a7a\\u59d0\\uff0c\\u5b66\\u751f\\uff0c\\u5c11\\u5987\\uff0c\\u603b\\u6709\\u4e00\\u6b3e\\u5c5e\\u4e8e\\u4f60\\uff01\\u6b22\\u8fce\\u52a0\\u5165\\u4e5d\\u7d2b\\u7231\\u604b\\uff0c\\u8d1f\\u8ddd\\u79bb\\u7684\\u63a5\\u89e6\\uff0c\\u5e1d\\u738b\\u822c\\u7684\\u9082\\u9005\\uff0c\\u5168\\u56fd\\u9876\\u7ea7\\u8d44\\u6e90\\uff0c\\u4e13\\u4e1a\\u7ea7\\u7684\\u670d\\u52a1\\uff01\\u6a21\\u7279 \\uff0c\\u7f51\\u7ea2\\uff0c\\u5fa1\\u59d0\\uff0c\\u841d\\u8389\\uff0c\\u7a7a\\u59d0\\uff0c\\u5b66\\u751f\\uff0c\\u5c11\\u5987\\uff0c\\u603b\\u6709\\u4e00\\u6b3e\\u5c5e\\u4e8e\\u4f60\\uff01\\u6b22\\u8fce\\u52a0\\u5165\\u4e5d\\u7d2b\\u7231\\u604b\\uff0c\\u8d1f\\u8ddd\\u79bb\\u7684\\u63a5\\u89e6\\uff0c\\u5e1d\\u738b\\u822c\\u7684\\u9082\\u9005\\uff0c\\u5168\\u56fd\\u9876\\u7ea7\\u8d44\\u6e90\\uff0c\\u4e13\\u4e1a\\u7ea7\\u7684\\u670d\\u52a1\\uff01\\u6a21\\u7279 \\uff0c\\u7f51\\u7ea2\\uff0c\\u5fa1\\u59d0\\uff0c\\u841d\\u8389\\uff0c\\u7a7a\\u59d0\\uff0c\\u5b66\\u751f\\uff0c\\u5c11\\u5987\\uff0c\\u603b\\u6709\\u4e00\\u6b3e\\u5c5e\\u4e8e\\u4f60\\uff01\\u6b22\\u8fce\\u52a0\\u5165\\u4e5d\\u7d2b\\u7231\\u604b\\uff0c\\u8d1f\\u8ddd\\u79bb\\u7684\\u63a5\\u89e6\\uff0c\\u5e1d\\u738b\\u822c\\u7684\\u9082\\u9005\\uff0c\\u5168\\u56fd\\u9876\\u7ea7\\u8d44\\u6e90\\uff0c\\u4e13\\u4e1a\\u7ea7\\u7684\\u670d\\u52a1\\uff01\\u6a21\\u7279 \\uff0c\\u7f51\\u7ea2\\uff0c\\u5fa1\\u59d0\\uff0c\\u841d\\u8389\\uff0c\\u7a7a\\u59d0\\uff0c\\u5b66\\u751f\\uff0c\\u5c11\\u5987\\uff0c\\u603b\\u6709\\u4e00\\u6b3e\\u5c5e\\u4e8e\\u4f60\\uff01<\\/span><img src=\\\"https:\\/\\/video.qlkc998.vip\\/uploads\\/file\\/junpfDq9Diff8hrU.jpg\\\"><\\/p>\"}}',2),(48,1,'2022-01-21 15:30:05','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"02f45aac9f4ba733547cdeba172e3708\",\"token_flush_at\":\"2022-01-19 17:59:53\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(49,1,'2022-01-21 15:32:54','185.135.73.218','/yw-video/edit','{\"before\":\"\",\"last\":{\"video_type_id\":\"1\",\"status\":2,\"image\":\"\\/uploads\\/file\\/a78LHAI2moHpU4mL.jpg\",\"remark\":\"\",\"order_num\":\"\",\"name\":\"\\u6211\\u662f\\u8d85\\u7ea7\\u6ca1\",\"update_time\":\"2022-01-21 15:32:54\",\"video_path\":\"\",\"video_url\":\"\\/uploads\\/file\\/vpRmXgK8tqoEKPi0.mp4\",\"type\":\"1\",\"rate\":\"\",\"create_time\":\"2022-01-21 15:32:54\"}}',1),(50,1,'2022-01-21 15:34:36','185.135.73.218','/yw-video/edit','{\"before\":\"\",\"last\":{\"video_type_id\":\"1\",\"status\":2,\"image\":\"\\/uploads\\/file\\/HKrMOBivwPuEhQnL.jpg\",\"remark\":\"\",\"order_num\":\"\",\"name\":\"123123123\",\"update_time\":\"2022-01-21 15:34:36\",\"video_path\":\"\",\"video_url\":\"\\/uploads\\/file\\/GF88Direhkq7868V.mp4\",\"type\":\"1\",\"rate\":\"\",\"create_time\":\"2022-01-21 15:34:36\"}}',1),(51,3,'2022-01-21 15:35:21','185.135.73.218','/login/login','{\"before\":{\"id\":3,\"username\":\"admin_example1\",\"password\":\"7038e563052562832ea7cb7c443c6ea1\",\"status\":1,\"create_time\":\"2021-05-22 12:38:37\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"be3e8abc01fdd84be128073cf9365e6e\",\"token_flush_at\":\"2022-01-19 16:42:56\",\"is_no_delete\":0,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(52,3,'2022-01-21 15:39:33','185.135.73.218','/yw-video/edit','{\"before\":\"\",\"last\":{\"video_type_id\":\"1\",\"status\":1,\"image\":\"\\/uploads\\/file\\/xP39EQ8i6tfLvaMG.jpg\",\"remark\":\"2123\",\"order_num\":\"400\",\"name\":\"121\",\"update_time\":\"2022-01-21 15:39:33\",\"video_path\":\"\",\"video_url\":\"\\/uploads\\/file\\/vU9ADbGsxT1OGa6k.mp4\",\"type\":\"1\",\"rate\":\"9.8\",\"create_time\":\"2022-01-21 15:39:33\"}}',1),(53,1,'2022-01-21 15:39:45','185.135.73.218','/yw-video/edit','{\"before\":\"\",\"last\":{\"video_type_id\":\"1\",\"status\":2,\"image\":\"\\/uploads\\/file\\/tZZRBptKMuXHr4xM.jpg\",\"remark\":\"\",\"order_num\":\"\",\"name\":\"123123123\",\"update_time\":\"2022-01-21 15:39:45\",\"video_path\":\"\",\"video_url\":\"\\/uploads\\/file\\/Ip9MmHLGzWbV1Nst.mp4\",\"type\":\"1\",\"rate\":\"\",\"create_time\":\"2022-01-21 15:39:45\"}}',1),(54,1,'2022-01-21 15:45:15','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"b0c4e360de32faef49c03f39607addef\",\"token_flush_at\":\"2022-01-21 15:30:05\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(55,1,'2022-01-21 15:45:15','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"b0c4e360de32faef49c03f39607addef\",\"token_flush_at\":\"2022-01-21 15:30:05\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(56,1,'2022-01-21 15:45:15','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"fc526823b4a4383bb80c3ce174016027\",\"token_flush_at\":\"2022-01-21 15:45:15\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(57,1,'2022-01-21 15:52:56','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"fc526823b4a4383bb80c3ce174016027\",\"token_flush_at\":\"2022-01-21 15:45:15\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(58,1,'2022-01-21 15:57:52','185.135.73.218','/yw-video/edit','{\"before\":\"\",\"last\":{\"video_type_id\":\"1\",\"status\":2,\"image\":\"\\/uploads\\/file\\/YofSnSgwRNA8itw0.jpg\",\"remark\":\"\",\"order_num\":\"\",\"name\":\"112312312\",\"update_time\":\"2022-01-21 15:57:52\",\"video_path\":\"https:\\/\\/video.qlkc998.vip\\/uploads\\/file\\/vU9ADbGsxT1OGa6k.mp4\",\"video_url\":\"\",\"type\":\"2\",\"rate\":\"\",\"create_time\":\"2022-01-21 15:57:52\"}}',1),(59,1,'2022-01-21 15:58:35','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"be0efcb13411dfd7b178f9d2fc345c9b\",\"token_flush_at\":\"2022-01-21 15:52:56\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(60,1,'2022-01-21 15:59:03','185.135.73.218','/yw-video/edit','{\"before\":\"\",\"last\":{\"video_type_id\":\"1\",\"status\":2,\"image\":\"\\/uploads\\/file\\/E7kS6bZTT5ZU0lvB.jpg\",\"remark\":\"\",\"order_num\":\"\",\"name\":\"234234234\",\"update_time\":\"2022-01-21 15:59:03\",\"video_path\":\"https:\\/\\/video.qlkc998.vip\\/uploads\\/file\\/vU9ADbGsxT1OGa6k.mp4\",\"video_url\":\"\",\"type\":\"2\",\"rate\":\"\",\"create_time\":\"2022-01-21 15:59:03\"}}',1),(61,1,'2022-01-21 15:59:52','185.135.73.218','/yw-video/edit','{\"before\":\"\",\"last\":{\"video_type_id\":\"1\",\"status\":2,\"image\":\"\\/uploads\\/file\\/pvjmgRIfikUOojwh.jpg\",\"remark\":\"\",\"order_num\":\"\",\"name\":\"123123123\",\"update_time\":\"2022-01-21 15:59:52\",\"video_path\":\"\",\"video_url\":\"\\/uploads\\/file\\/fn29iQ341PJrzu9H.mp4\",\"type\":\"1\",\"rate\":\"\",\"create_time\":\"2022-01-21 15:59:52\"}}',1),(62,1,'2022-01-21 16:03:03','185.135.73.218','/yw-video/edit','{\"before\":\"\",\"last\":{\"video_type_id\":\"1\",\"status\":1,\"image\":\"\\/uploads\\/file\\/HqFWw0m7ODKNZWQt.jpg\",\"remark\":\"12\",\"order_num\":\"900\",\"name\":\"12\",\"update_time\":\"2022-01-21 16:03:03\",\"video_path\":\"\",\"video_url\":\"\\/uploads\\/file\\/G9jeOx7d1kmM5kml.mp4\",\"type\":\"1\",\"rate\":\"9.8\",\"create_time\":\"2022-01-21 16:03:03\"}}',1),(63,1,'2022-01-21 16:03:23','185.135.73.218','/yw-video/edit','{\"before\":\"\",\"last\":{\"video_type_id\":\"1\",\"status\":1,\"image\":\"\\/uploads\\/file\\/HqFWw0m7ODKNZWQt.jpg\",\"remark\":\"12\",\"order_num\":\"900\",\"name\":\"12\",\"update_time\":\"2022-01-21 16:03:23\",\"video_path\":\"1212\",\"video_url\":\"\\/uploads\\/file\\/G9jeOx7d1kmM5kml.mp4\",\"type\":\"2\",\"rate\":\"9.80\"}}',2),(64,1,'2022-01-21 16:04:59','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"1186aa1edfa94957f92a56a36057bd76\",\"token_flush_at\":\"2022-01-21 15:58:35\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(65,1,'2022-01-21 16:05:29','185.135.73.218','/yw-video/edit','{\"before\":\"\",\"last\":{\"video_type_id\":\"1\",\"status\":1,\"image\":\"\\/uploads\\/file\\/seHocqxKivi1WYBK.jpg\",\"remark\":\"9\",\"order_num\":\"9999\",\"name\":\"234234234234\",\"update_time\":\"2022-01-21 16:05:29\",\"video_path\":\"https:\\/\\/video.qlkc998.vip\\/uploads\\/file\\/vU9ADbGsxT1OGa6k.mp4\",\"video_url\":\"\",\"type\":\"2\",\"rate\":\"9\",\"create_time\":\"2022-01-21 16:05:29\"}}',1),(66,3,'2022-01-21 16:18:05','185.135.73.218','/login/login','{\"before\":{\"id\":3,\"username\":\"admin_example1\",\"password\":\"7038e563052562832ea7cb7c443c6ea1\",\"status\":1,\"create_time\":\"2021-05-22 12:38:37\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"c56db003f00e187fcc89a6b09cd4b1ed\",\"token_flush_at\":\"2022-01-21 15:35:21\",\"is_no_delete\":0,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(67,1,'2022-01-21 17:10:39','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"a5d38d01e28246fccc95820a8ad1805d\",\"token_flush_at\":\"2022-01-21 16:04:59\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(68,1,'2022-01-21 17:12:06','185.135.73.218','/yw-notice/edit','{\"before\":\"\",\"last\":{\"title\":\"\\u6b22\\u8fce\\u52a0\\u5165\\u4e5d\\uff0c\\u8d1f\\u8ddd\\u79bb\\u7684\\u63a5\\u89e6\\uff0c\\u5e1d\\u738b\\u822c\\u7684\\u9082\\u9005\\uff0c\\u5168\\u56fd\\u9876\\u7ea7\\u8d44\\u6e90\\uff0c\\u4e13\\u4e1a\\u7ea7\\u7684\\u670d\\u52a1\\uff01\\u6a21\\u7279 \\uff0c\\u7f51\\u7ea2\\uff0c\\u5fa1\\u59d0\\uff0c\\u841d\\u8389\\uff0c\\u7a7a\\u59d0\\uff0c\\u5b66\\u751f\\uff0c\\u5c11\\u5987\\uff0c\\u603b\\u6709\\u4e00\\u6b3e\\u5c5e\\u4e8e\\u4f60\\uff01\",\"detail\":\"<p>123123123123<\\/p>\"}}',2),(69,1,'2022-01-21 17:12:25','185.135.73.218','/yw-notice/edit','{\"before\":\"\",\"last\":{\"title\":\"2342342342342345345\",\"detail\":\"<p>123123123123<\\/p>\"}}',2),(70,1,'2022-01-21 17:17:43','185.135.73.218','/yw-notice/edit','{\"before\":\"\",\"last\":{\"title\":\"\\u68ee\\u6c34\\u9601APP-\\u76ee\\u524d\\u5168\\u56fd\\u6700\\u5927\\u7684\\u540c\\u57ce\\u6027\\u7231\\u670d\\u52a1\\u5e73\\u53f0!\\u4e3b\\u8425\\u4e1a\\u52a1\\u5168\\u56fd\\u5404\\u4e2a\\u57ce\\u5e02\\u3002\\u63d0\\u4f9b\\u6a21\\u7279\\u3001\\u7f51\\u7ea2\\u3001\\u6027\\u64ad\\u3001\\u7a7a\\u59d0\\u3001\\u62a4\\u58eb\\u3001\\u767d\\u9886\\u3001\\u4eba\\u59bb\\u300100\\u540e\\u3001\\u5916\\u56f4\\u3001\\u5b55\\u5987\\u3001\\u5b66\\u751f\\u3001\\u5c11\\u5987\\u3001\\u59d0\\u59b9\\u82b1\\u3001\\u6bcd\\u5973\\u82b1\\u3001\\u957f\\u671f\\u6027\\u4f34\\u4fa3\\u7b49, \\u66f4\\u6709\\u5546\\u52a1\\u5b98\\u5458\\u79c1\\u5bc6\\u670d\\u52a1,\\u65c5\\u884c\\u966a\\u4f34\\u6027\\u7231\\u7f8e\\u5973\\u7b49,\\u672c\\u5e73\\u53f0\\u65bd\\u884c\\u8d35\\u5bbe\\u5236\\u4e0d\\u5bf9\\u5916\\u5408\\u4f5c  \\u8be6\\u60c5\\u8054\\u7cfb\\u63a5\\u5f85\\u5458\\u5373\\u53ef\\u3002\",\"detail\":\"<p>\\u4e8c \\u80d6, [2022\\/1\\/21 13:34]<\\/p><p>\\u68ee\\u6c34\\u9601APP-\\u76ee\\u524d\\u5168\\u56fd\\u6700\\u5927\\u7684\\u540c\\u57ce\\u6027\\u7231\\u670d\\u52a1\\u5e73\\u53f0!\\u4e3b\\u8425\\u4e1a\\u52a1\\u5168\\u56fd\\u5404\\u4e2a\\u57ce\\u5e02\\u3002\\u63d0\\u4f9b\\u6a21\\u7279\\u3001\\u7f51\\u7ea2\\u3001\\u6027\\u64ad\\u3001\\u7a7a\\u59d0\\u3001\\u62a4\\u58eb\\u3001\\u767d\\u9886\\u3001\\u4eba\\u59bb\\u300100\\u540e\\u3001\\u5916\\u56f4\\u3001\\u5b55\\u5987\\u3001\\u5b66\\u751f\\u3001\\u5c11\\u5987\\u3001\\u59d0\\u59b9\\u82b1\\u3001\\u6bcd\\u5973\\u82b1\\u3001\\u957f\\u671f\\u6027\\u4f34\\u4fa3\\u7b49, \\u66f4\\u6709\\u5546\\u52a1\\u5b98\\u5458\\u79c1\\u5bc6\\u670d\\u52a1,\\u65c5\\u884c\\u966a\\u4f34\\u6027\\u7231\\u7f8e\\u5973\\u7b49,\\u672c\\u5e73\\u53f0\\u65bd\\u884c\\u8d35\\u5bbe\\u5236\\u4e0d\\u5bf9\\u5916\\u5408\\u4f5c&nbsp;\\u8be6\\u60c5\\u8054\\u7cfb\\u63a5\\u5f85\\u5458\\u5373\\u53ef\\u3002<\\/p>\"}}',2),(71,1,'2022-01-21 17:35:18','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"4b6ea419cf253dfb1089ac79074e828c\",\"token_flush_at\":\"2022-01-21 17:10:39\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(72,1,'2022-01-21 17:48:37','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"ff1410ad1eda5b488c595179f0186be7\",\"token_flush_at\":\"2022-01-21 17:35:18\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(73,1,'2022-01-21 17:48:37','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"14ee20f4c02da2c8ea6c69309282e4da\",\"token_flush_at\":\"2022-01-21 17:48:37\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(74,1,'2022-01-21 17:48:37','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"14ee20f4c02da2c8ea6c69309282e4da\",\"token_flush_at\":\"2022-01-21 17:48:37\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(75,1,'2022-01-21 17:48:53','185.135.73.218','/yw-notice/edit','{\"before\":\"\",\"last\":{\"title\":\"\\u68ee\\u6c34\\u9601APP-\\u76ee\\u524d\\u5168\\u56fd\\u6700\\u5927\\u7684\\u540c\\u57ce\\u6027\\u7231\\u670d\\u52a1\\u5e73\\u53f0!\\u4e3b\\u8425\\u4e1a\\u52a1\\u5168\\u56fd\\u5404\\u4e2a\\u57ce\\u5e02\\u3002\\u63d0\\u4f9b\\u6a21\\u7279\\u3001\\u7f51\\u7ea2\\u3001\\u6027\\u64ad\\u3001\\u7a7a\\u59d0\\u3001\\u62a4\\u58eb\\u3001\\u767d\\u9886\\u3001\\u4eba\\u59bb\\u300100\\u540e\\u3001\\u5916\\u56f4\\u3001\\u5b55\\u5987\\u3001\\u5b66\\u751f\\u3001\\u5c11\\u5987\\u3001\\u59d0\\u59b9\\u82b1\\u3001\\u6bcd\\u5973\\u82b1\\u3001\\u957f\\u671f\\u6027\\u4f34\\u4fa3\\u7b49, \\u66f4\\u6709\\u5546\\u52a1\\u5b98\\u5458\\u79c1\\u5bc6\\u670d\\u52a1,\\u65c5\\u884c\\u966a\\u4f34\\u6027\\u7231\\u7f8e\\u5973\\u7b49,\\u672c\\u5e73\\u53f0\\u65bd\\u884c\\u8d35\\u5bbe\\u5236\\u4e0d\\u5bf9\\u5916\\u5408\\u4f5c  \\u8be6\\u60c5\\u8054\\u7cfb\\u63a5\\u5f85\\u5458\\u5373\\u53ef\\u3002\",\"detail\":\"<p>\\u68ee\\u6c34\\u9601APP-\\u76ee\\u524d\\u5168\\u56fd\\u6700\\u5927\\u7684\\u540c\\u57ce\\u6027\\u7231\\u670d\\u52a1\\u5e73\\u53f0!\\u4e3b\\u8425\\u4e1a\\u52a1\\u5168\\u56fd\\u5404\\u4e2a\\u57ce\\u5e02\\u3002\\u63d0\\u4f9b\\u6a21\\u7279\\u3001\\u7f51\\u7ea2\\u3001\\u6027\\u64ad\\u3001\\u7a7a\\u59d0\\u3001\\u62a4\\u58eb\\u3001\\u767d\\u9886\\u3001\\u4eba\\u59bb\\u300100\\u540e\\u3001\\u5916\\u56f4\\u3001\\u5b55\\u5987\\u3001\\u5b66\\u751f\\u3001\\u5c11\\u5987\\u3001\\u59d0\\u59b9\\u82b1\\u3001\\u6bcd\\u5973\\u82b1\\u3001\\u957f\\u671f\\u6027\\u4f34\\u4fa3\\u7b49, \\u66f4\\u6709\\u5546\\u52a1\\u5b98\\u5458\\u79c1\\u5bc6\\u670d\\u52a1,\\u65c5\\u884c\\u966a\\u4f34\\u6027\\u7231\\u7f8e\\u5973\\u7b49,\\u672c\\u5e73\\u53f0\\u65bd\\u884c\\u8d35\\u5bbe\\u5236\\u4e0d\\u5bf9\\u5916\\u5408\\u4f5c&nbsp;\\u8be6\\u60c5\\u8054\\u7cfb\\u63a5\\u5f85\\u5458\\u5373\\u53ef\\u3002<\\/p>\"}}',2),(76,1,'2022-01-21 18:46:17','185.135.73.218','/yw-video/edit','{\"before\":\"\",\"last\":{\"video_type_id\":\"1\",\"status\":1,\"image\":\"\\/uploads\\/file\\/seHocqxKivi1WYBK.jpg\",\"remark\":\"9\",\"order_num\":\"9999\",\"name\":\"91\\u70ed\\u95e8\\u89c6\\u9891\",\"update_time\":\"2022-01-21 18:46:17\",\"video_path\":\"https:\\/\\/video.qlkc998.vip\\/uploads\\/file\\/vU9ADbGsxT1OGa6k.mp4\",\"video_url\":\"\",\"type\":\"2\",\"rate\":\"9.00\"}}',2),(77,1,'2022-01-21 18:47:21','185.135.73.218','/yw-video/edit','{\"before\":\"\",\"last\":{\"video_type_id\":\"1\",\"status\":2,\"image\":\"\\/uploads\\/file\\/xP39EQ8i6tfLvaMG.jpg\",\"remark\":\"2123\",\"order_num\":\"400\",\"name\":\"121\",\"update_time\":\"2022-01-21 18:47:21\",\"video_path\":\"\",\"video_url\":\"\\/uploads\\/file\\/vU9ADbGsxT1OGa6k.mp4\",\"type\":\"1\",\"rate\":\"9.80\"}}',2),(78,1,'2022-01-21 18:47:31','185.135.73.218','/yw-video/edit','{\"before\":\"\",\"last\":{\"video_type_id\":\"1\",\"status\":2,\"image\":\"\\/uploads\\/file\\/HqFWw0m7ODKNZWQt.jpg\",\"remark\":\"12\",\"order_num\":\"900\",\"name\":\"12\",\"update_time\":\"2022-01-21 18:47:31\",\"video_path\":\"1212\",\"video_url\":\"\\/uploads\\/file\\/G9jeOx7d1kmM5kml.mp4\",\"type\":\"2\",\"rate\":\"9.80\"}}',2),(79,1,'2022-01-21 19:26:00','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"14ee20f4c02da2c8ea6c69309282e4da\",\"token_flush_at\":\"2022-01-21 17:48:37\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(80,1,'2022-01-21 19:33:22','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"cb0a1110ffeb4cffc8cacdb295b0cbeb\",\"token_flush_at\":\"2022-01-21 19:26:00\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(81,1,'2022-01-21 19:37:32','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"3f8ef16d35d88011e7b15be8add960bb\",\"token_flush_at\":\"2022-01-21 19:33:22\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(82,1,'2022-01-21 19:37:32','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"3f8ef16d35d88011e7b15be8add960bb\",\"token_flush_at\":\"2022-01-21 19:33:22\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(83,1,'2022-01-21 19:38:11','185.135.73.218','/yw-video/edit','{\"before\":\"\",\"last\":{\"video_type_id\":\"1\",\"status\":1,\"image\":\"\\/uploads\\/file\\/88XHwQg27z3svrFD.jpg\",\"remark\":\"6\",\"order_num\":\"1\",\"name\":\"91\",\"update_time\":\"2022-01-21 19:38:11\",\"video_path\":\"https:\\/\\/t.me\\/wokong1\\/27762?single\",\"video_url\":\"\",\"type\":\"2\",\"rate\":\"9\",\"create_time\":\"2022-01-21 19:38:11\"}}',1),(84,1,'2022-01-21 19:41:43','185.135.73.218','/yw-video/delete','{\"before\":{\"id\":39,\"create_time\":\"2022-01-21 19:38:11\",\"view_num\":0,\"status\":1,\"order_num\":1,\"video_type_id\":1,\"name\":\"91\",\"update_time\":\"2022-01-21 19:38:11\",\"image\":\"\\/uploads\\/file\\/88XHwQg27z3svrFD.jpg\",\"video_path\":\"https:\\/\\/t.me\\/wokong1\\/27762?single\",\"type\":2,\"remark\":\"6\",\"video_url\":\"\",\"rate\":\"9.00\"},\"last\":\"\"}',3),(85,1,'2022-01-21 20:17:57','185.135.73.218','/login/login','{\"before\":{\"id\":1,\"username\":\"admin_example\",\"password\":\"1712bd12a72ffd99ee82b1110385b69e\",\"status\":1,\"create_time\":\"2021-05-21 19:33:18\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"db68317bb0c45a4deaed2061b9b451e9\",\"token_flush_at\":\"2022-01-21 19:37:32\",\"is_no_delete\":1,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4),(86,3,'2022-01-21 20:55:52','185.135.73.218','/login/login','{\"before\":{\"id\":3,\"username\":\"admin_example1\",\"password\":\"7038e563052562832ea7cb7c443c6ea1\",\"status\":1,\"create_time\":\"2021-05-22 12:38:37\",\"role_id\":1,\"city_config_id\":282,\"remark\":\"\",\"mobile\":\"13540295237\",\"token\":\"f6539b296b500f491867e3e1c17a5d62\",\"token_flush_at\":\"2022-01-21 16:18:05\",\"is_no_delete\":0,\"city_config_arr\":\"[\\\"22\\\",\\\"282\\\"]\"},\"last\":\"\"}',4);
/*!40000 ALTER TABLE `ywsm_common_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ywsm_common_menu`
--

DROP TABLE IF EXISTS `ywsm_common_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ywsm_common_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '菜单表',
  `title` varchar(255) NOT NULL COMMENT '模块名称',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态 1显示  2隐藏',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT '父级ID',
  `create_time` datetime DEFAULT NULL,
  `order_num` int(11) NOT NULL DEFAULT '0' COMMENT '排序值',
  `is_load` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否加载[该字段针对开发用]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ywsm_common_menu`
--

LOCK TABLES `ywsm_common_menu` WRITE;
/*!40000 ALTER TABLE `ywsm_common_menu` DISABLE KEYS */;
INSERT INTO `ywsm_common_menu` VALUES (1,'权限管理','',1,0,'2021-05-21 21:24:14',10,1),(2,'管理员列表','/admin/admin',1,1,'2021-05-21 21:25:03',0,1),(3,'角色管理','/admin/role',1,1,'2021-05-21 21:25:03',0,1),(4,'菜单管理','/admin/menu',1,1,'2021-05-21 21:25:03',0,1),(6,'权限分配','/admin/auth',1,1,'2021-05-22 10:40:43',0,1),(7,'视频管理','',1,0,'2021-05-22 15:12:44',0,1),(23,'视频分类','/system/video-type',1,7,'2022-01-17 15:10:26',0,1),(24,'城市管理','/system/city',2,27,'2022-01-17 15:10:26',0,1),(25,'选美列表','/system/beautiful',2,27,'2022-01-17 15:10:26',0,1),(26,'视频管理','/system/video',1,7,'2022-01-17 15:10:26',0,1),(27,'选美管理','',2,0,'2022-01-19 14:57:39',1,1),(28,'公告管理','',1,0,'2022-01-20 19:17:29',0,1),(29,'公告列表','/system/notice',1,28,'2022-01-20 19:17:44',0,1);
/*!40000 ALTER TABLE `ywsm_common_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ywsm_common_role`
--

DROP TABLE IF EXISTS `ywsm_common_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ywsm_common_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '角色表',
  `name` varchar(255) NOT NULL COMMENT '角色名称',
  `create_time` datetime DEFAULT NULL,
  `is_no_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否可删除[0 可以 1不可以]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ywsm_common_role`
--

LOCK TABLES `ywsm_common_role` WRITE;
/*!40000 ALTER TABLE `ywsm_common_role` DISABLE KEYS */;
INSERT INTO `ywsm_common_role` VALUES (1,'超级管理员','2021-05-22 10:00:06',1),(2,'副管理员','2021-05-22 11:01:56',0);
/*!40000 ALTER TABLE `ywsm_common_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ywsm_common_route`
--

DROP TABLE IF EXISTS `ywsm_common_route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ywsm_common_route` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '路由表',
  `name` varchar(255) NOT NULL COMMENT '路由名称',
  `create_time` datetime DEFAULT NULL,
  `path` varchar(255) NOT NULL COMMENT '路径',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ywsm_common_route`
--

LOCK TABLES `ywsm_common_route` WRITE;
/*!40000 ALTER TABLE `ywsm_common_route` DISABLE KEYS */;
/*!40000 ALTER TABLE `ywsm_common_route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ywsm_yw_beautiful`
--

DROP TABLE IF EXISTS `ywsm_yw_beautiful`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ywsm_yw_beautiful` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '选美',
  `image` varchar(255) NOT NULL COMMENT '图片',
  `order_num` int(11) NOT NULL DEFAULT '0' COMMENT '排序值',
  `create_time` datetime DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '-1 删除 1显示 0隐藏',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `name` varchar(255) NOT NULL COMMENT '标题',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `city_id` int(11) NOT NULL COMMENT '城市ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ywsm_yw_beautiful`
--

LOCK TABLES `ywsm_yw_beautiful` WRITE;
/*!40000 ALTER TABLE `ywsm_yw_beautiful` DISABLE KEYS */;
INSERT INTO `ywsm_yw_beautiful` VALUES (1,'/uploads/file/p7CGjXO4KruY5n8B.jpg',12,'2022-01-17 16:27:57',1,'2022-01-19 15:21:56','123','123',1);
/*!40000 ALTER TABLE `ywsm_yw_beautiful` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ywsm_yw_city`
--

DROP TABLE IF EXISTS `ywsm_yw_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ywsm_yw_city` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '省市管理',
  `name` varchar(255) NOT NULL COMMENT '省市名称',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '-1 删除 1显示 0隐藏',
  `order_num` int(11) NOT NULL DEFAULT '0',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `remark` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ywsm_yw_city`
--

LOCK TABLES `ywsm_yw_city` WRITE;
/*!40000 ALTER TABLE `ywsm_yw_city` DISABLE KEYS */;
INSERT INTO `ywsm_yw_city` VALUES (1,'成都',1,10,'2022-01-17 15:31:16','2022-01-17 15:31:16','成都'),(2,'西安',1,12,'2022-01-19 16:48:13','2022-01-19 16:48:13','西安');
/*!40000 ALTER TABLE `ywsm_yw_city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ywsm_yw_notice`
--

DROP TABLE IF EXISTS `ywsm_yw_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ywsm_yw_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '公告',
  `title` varchar(255) NOT NULL,
  `detail` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ywsm_yw_notice`
--

LOCK TABLES `ywsm_yw_notice` WRITE;
/*!40000 ALTER TABLE `ywsm_yw_notice` DISABLE KEYS */;
INSERT INTO `ywsm_yw_notice` VALUES (1,'森水阁APP-目前全国最大的同城性爱服务平台!主营业务全国各个城市。提供模特、网红、性播、空姐、护士、白领、人妻、00后、外围、孕妇、学生、少妇、姐妹花、母女花、长期性伴侣等, 更有商务官员私密服务,旅行陪伴性爱美女等,本平台施行贵宾制不对外合作  详情联系接待员即可。','<p>森水阁APP-目前全国最大的同城性爱服务平台!主营业务全国各个城市。提供模特、网红、性播、空姐、护士、白领、人妻、00后、外围、孕妇、学生、少妇、姐妹花、母女花、长期性伴侣等, 更有商务官员私密服务,旅行陪伴性爱美女等,本平台施行贵宾制不对外合作&nbsp;详情联系接待员即可。</p>');
/*!40000 ALTER TABLE `ywsm_yw_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ywsm_yw_video`
--

DROP TABLE IF EXISTS `ywsm_yw_video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ywsm_yw_video` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` datetime DEFAULT NULL,
  `view_num` int(11) NOT NULL DEFAULT '0' COMMENT '播放次数',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '-1 删除 1显示 0隐藏',
  `order_num` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `video_type_id` int(11) NOT NULL COMMENT '类型',
  `name` varchar(255) NOT NULL COMMENT '产品名称',
  `update_time` datetime DEFAULT NULL COMMENT '删除时间',
  `image` varchar(255) NOT NULL COMMENT '显示图片',
  `video_path` varchar(255) NOT NULL COMMENT '视频地址',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 上传  2链接',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `video_url` varchar(255) NOT NULL DEFAULT '' COMMENT '视频地址()',
  `rate` decimal(10,2) NOT NULL DEFAULT '9.80',
  PRIMARY KEY (`id`),
  KEY `status_is_delete_is_start_limit` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ywsm_yw_video`
--

LOCK TABLES `ywsm_yw_video` WRITE;
/*!40000 ALTER TABLE `ywsm_yw_video` DISABLE KEYS */;
INSERT INTO `ywsm_yw_video` VALUES (1,'2022-01-19 09:59:59',0,1,124,1,'我爱女友实境秀','2022-01-19 15:21:37','/uploads/file/11.jpg','',1,'12','/uploads/video/11111.mp4',9.80),(2,'2022-01-19 17:03:39',0,1,123,1,' 紧身裤白衣妹子坐身上摸摸 舔奶掰穴镜头前口交抬腿侧入','2022-01-19 17:03:39','/uploads/file/22.jpg','',1,'123','/uploads/video/11111.mp4',9.80),(3,'2022-01-19 17:03:39',0,1,123,1,'泳装少女_泳装啪啪_口_乘骑_后入_乳推_道具','2022-01-19 17:03:39','/uploads/file/33.jpg','',1,'123','/uploads/video/11111.mp4',9.80),(4,'2022-01-19 17:03:39',0,1,123,1,'援交妹子情趣黑丝开档被干大叫爸爸干我用力','2022-01-19 17:03:39','/uploads/file/44.jpg','',1,'123','/uploads/video/11111.mp4',9.80),(5,'2022-01-19 17:03:39',0,1,123,1,'JK美少女  翘臀','2022-01-19 17:03:39','/uploads/file/55.jpg','',1,'123','/uploads/video/11111.mp4',9.80),(6,'2022-01-19 17:03:39',0,1,123,1,'这次跟哥们一起尝尝瘦弱高挑的泰国美女','2022-01-19 17:03:39','/uploads/file/66.jpg','',1,'123','/uploads/video/11111.mp4',9.80),(7,'2022-01-19 17:03:39',0,1,123,1,'爆口 粉嫩 二次元少女','2022-01-19 17:03:39','/uploads/file/77.jpg','',1,'123','/uploads/video/11111.mp4',9.80),(8,'2022-01-19 17:03:39',0,1,123,1,'小姐姐全程露脸无毛白虎逼','2022-01-19 17:03:39','/uploads/file/88.jpg','',1,'123','/uploads/video/11111.mp4',9.80),(9,'2022-01-19 17:03:39',0,1,123,1,'粉嫩_可爱_蓝白条纹双马尾萌妹_电棒自慰_肉粉粉','2022-01-19 17:03:39','/uploads/file/99.jpg','',1,'123','/uploads/video/11111.mp4',9.80),(10,'2022-01-19 17:03:39',0,1,123,1,'皮肤白皙身材不错美乳妹子床上自慰没摸几下就出水高潮直接尿尿','2022-01-19 17:03:39','/uploads/file/1010.jpg','',1,'123','/uploads/video/11111.mp4',9.80),(11,'2022-01-19 17:03:39',0,1,123,1,'身材不错的师范学妹穿着情趣内衣装，阴毛有些稀疏，被精瘦小伙快速抽插浪叫呻吟','2022-01-19 17:03:39','/uploads/file/1111.jpg','',1,'123','/uploads/video/11111.mp4',9.80),(12,'2022-01-19 17:03:39',0,1,123,1,'极品华裔白嫩女神与大屌洋男友尝试高难姿势 爽得嗷嗷大叫','2022-01-19 17:03:39','/uploads/file/1212.jpg','',1,'123','/uploads/video/11111.mp4',9.80),(13,'2022-01-19 17:03:39',0,1,123,1,'超级美女与男友在酒店交玩足，这颜值让我看得撸了三次','2022-01-19 17:03:39','/uploads/file/1313.jpg','',1,'123','/uploads/video/11111.mp4',9.80),(14,'2022-01-19 17:03:39',0,1,123,1,'穿开档情趣内衣的无毛粉木耳少女和狼友啪啪 然后用苦瓜插穴自慰','2022-01-19 17:03:39','/uploads/file/1515.jpg','',1,'123','/uploads/video/11111.mp4',9.80),(15,'2022-01-19 17:03:39',0,1,123,1,'中年男约了位丰满气质的大奶少妇酒店迫不及待开操,干的相当激烈','2022-01-19 17:03:39','/uploads/file/1616.jpg','',1,'123','/uploads/video/11111.mp4',9.80),(30,'2022-01-21 15:32:54',0,2,0,1,'我是超级没','2022-01-21 15:32:54','/uploads/file/a78LHAI2moHpU4mL.jpg','',1,'','/uploads/file/vpRmXgK8tqoEKPi0.mp4',0.00),(31,'2022-01-21 15:34:36',0,2,0,1,'123123123','2022-01-21 15:34:36','/uploads/file/HKrMOBivwPuEhQnL.jpg','',1,'','/uploads/file/GF88Direhkq7868V.mp4',0.00),(32,'2022-01-21 15:39:33',0,2,400,1,'121','2022-01-21 18:47:21','/uploads/file/xP39EQ8i6tfLvaMG.jpg','',1,'2123','/uploads/file/vU9ADbGsxT1OGa6k.mp4',9.80),(33,'2022-01-21 15:39:45',0,2,0,1,'123123123','2022-01-21 15:39:45','/uploads/file/tZZRBptKMuXHr4xM.jpg','',1,'','/uploads/file/Ip9MmHLGzWbV1Nst.mp4',0.00),(34,'2022-01-21 15:57:52',0,2,0,1,'112312312','2022-01-21 15:57:52','/uploads/file/YofSnSgwRNA8itw0.jpg','https://video.qlkc998.vip/uploads/file/vU9ADbGsxT1OGa6k.mp4',2,'','',0.00),(35,'2022-01-21 15:59:03',0,2,0,1,'234234234','2022-01-21 15:59:03','/uploads/file/E7kS6bZTT5ZU0lvB.jpg','https://video.qlkc998.vip/uploads/file/vU9ADbGsxT1OGa6k.mp4',2,'','',0.00),(36,'2022-01-21 15:59:52',0,2,0,1,'123123123','2022-01-21 15:59:52','/uploads/file/pvjmgRIfikUOojwh.jpg','',1,'','/uploads/file/fn29iQ341PJrzu9H.mp4',0.00),(37,'2022-01-21 16:03:03',0,2,900,1,'12','2022-01-21 18:47:31','/uploads/file/HqFWw0m7ODKNZWQt.jpg','1212',2,'12','/uploads/file/G9jeOx7d1kmM5kml.mp4',9.80),(38,'2022-01-21 16:05:29',0,1,9999,1,'91热门视频','2022-01-21 18:46:17','/uploads/file/seHocqxKivi1WYBK.jpg','https://video.qlkc998.vip/uploads/file/vU9ADbGsxT1OGa6k.mp4',2,'9','',9.00),(39,'2022-01-21 19:38:11',0,-1,1,1,'91','2022-01-21 19:41:43','/uploads/file/88XHwQg27z3svrFD.jpg','https://t.me/wokong1/27762?single',2,'6','',9.00);
/*!40000 ALTER TABLE `ywsm_yw_video` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ywsm_yw_video_type`
--

DROP TABLE IF EXISTS `ywsm_yw_video_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ywsm_yw_video_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '视频类型',
  `name` varchar(255) NOT NULL COMMENT '名称',
  `create_time` datetime DEFAULT NULL,
  `order_num` int(11) NOT NULL DEFAULT '0' COMMENT '排序值',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '-1 删除 1显示 0隐藏',
  `update_time` datetime DEFAULT NULL COMMENT '编辑时间',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ywsm_yw_video_type`
--

LOCK TABLES `ywsm_yw_video_type` WRITE;
/*!40000 ALTER TABLE `ywsm_yw_video_type` DISABLE KEYS */;
INSERT INTO `ywsm_yw_video_type` VALUES (1,'精品推荐','2022-01-17 15:12:23',100,1,'2022-01-17 15:13:08','精品推荐'),(2,'j','2022-01-19 17:43:37',0,2,'2022-01-19 17:43:37','');
/*!40000 ALTER TABLE `ywsm_yw_video_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'sql_videoadmin_q'
--

--
-- Dumping routines for database 'sql_videoadmin_q'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-21 20:58:26
